from diccionario import Palabra, Diccionario, Usuario


def mostrarMenu():
    dicc = Diccionario.crearVacio("Mi Diccionario")
    usuario = Usuario("Pablo")
    opcion = -1

    while opcion != 0:
        print("\n BUSCADOR DE DEFINICIONES")
        print(dicc)
        print("1. Registrar palabra")
        print("2. Buscar palabra")
        print("3. Modificar definición")
        print("4. Listar palabras")
        print("5. Ver historial de consultas")
        print("0. Salir")

        opcion = int(input("Elija una opción: "))

        if opcion == 1:
            termino = input("Palabra: ")
            definicion = input("Definición: ")
            dicc.agregarPalabra(Palabra(termino, definicion))

        elif opcion == 2:
            termino = input("¿Qué palabra buscas?: ")
            usuario.consultar(dicc, termino)

        elif opcion == 3:
            termino = input("Palabra a modificar: ")
            nueva_definicion = input("Nueva definición: ")
            dicc.modificarDefinicion(termino, nueva_definicion)

        elif opcion == 4:
            dicc.listar()

        elif opcion == 5:
            usuario.verHistorial()

        elif opcion != 0:
            print("Opción no válida.")


if __name__ == "__main__":
    mostrarMenu()
