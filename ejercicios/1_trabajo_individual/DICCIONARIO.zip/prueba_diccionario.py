from diccionario import Palabra, Diccionario, Usuario

dicc = Diccionario.crearVacio("Diccionario de POO")
dicc.agregarPalabra(Palabra("Clase", "Molde que define atributos y métodos de un objeto."))
dicc.agregarPalabra(Palabra("Objeto", "Instancia concreta de una clase."))

usuario = Usuario("Pablo")

print("\n Consultas ")
usuario.consultar(dicc, "clase")     
usuario.consultar(dicc, "herencia")  

print("\n Modificar definición")
dicc.modificarDefinicion("Objeto", "Ejemplar creado a partir de una clase.")

print("\n Listado final")
dicc.listar()

print("\n Historial del usuario")
usuario.verHistorial()

print("\nCantidad de palabras (len):", len(dicc))
print(dicc)
print(usuario)
