class Palabra:

    def __init__(self, termino, definicion):
        self.termino = termino                  
        self._definicion = definicion           
        self.__veces_consultada = 0             

    @property
    def definicion(self):
        return self._definicion

    @definicion.setter
    def definicion(self, nueva_definicion):
        if nueva_definicion.strip() == "":
            print("La definición no puede estar vacía.")
        else:
            self._definicion = nueva_definicion

    @property
    def veces_consultada(self):
        return self.__veces_consultada

    # ---------- Método ----------
    def incrementarConsulta(self):
        self.__veces_consultada += 1

    def __str__(self):
        return f"{self.termino}: {self._definicion} (consultada {self.__veces_consultada} veces)"


class Diccionario:


    def __init__(self, nombre):
        self.nombre = nombre
        self.palabras = []  

    def agregarPalabra(self, palabra):
        self.palabras.append(palabra)
        print(f"'{palabra.termino}' agregada al diccionario.")

    def buscar(self, termino):
        termino = Diccionario.normalizar(termino)
        for palabra in self.palabras:
            if Diccionario.normalizar(palabra.termino) == termino:
                return palabra
        return None

    def modificarDefinicion(self, termino, nueva_definicion):
        palabra = self.buscar(termino)
        if palabra:
            palabra.definicion = nueva_definicion
            print("Definición actualizada.")
        else:
            print("La palabra no existe en el diccionario.")

    def listar(self):
        if not self.palabras:
            print("El diccionario está vacío.")
        for palabra in self.palabras:
            print(palabra)
            
    @classmethod
    def crearVacio(cls, nombre):
        return cls(nombre)

    @staticmethod
    def normalizar(texto):
        return texto.strip().lower()

    def __len__(self):
        return len(self.palabras)

    def __str__(self):
        return f"Diccionario '{self.nombre}' con {len(self.palabras)} palabras"

class Usuario:

    def __init__(self, nombre):
        self.nombre = nombre
        self.historial = []

    def consultar(self, diccionario, termino):
        palabra = diccionario.buscar(termino)
        self.historial.append(termino)
        if palabra:
            palabra.incrementarConsulta()
            print(palabra)
        else:
            print(f"'{termino}' no se encontró en el diccionario.")

    def verHistorial(self):
        if not self.historial:
            print("Aún no has hecho consultas.")
        for i, termino in enumerate(self.historial):
            print(f"{i}. {termino}")

    def __str__(self):
        return f"Usuario: {self.nombre} | {len(self.historial)} consultas realizadas"
